# -------------------------------------------------------------------------------- NOTEBOOK-CELL: CODE
# -*- coding: utf-8 -*-
import dataiku
import pandas as pd, numpy as np
from dataiku import pandasutils as pdu

# Read recipe inputs
stage_claims_hdfs_distinct_providerIDs_prepared = dataiku.Dataset("stage_claims_hdfs_distinct_providerIDs_prepared")
stage_claims_hdfs_distinct_providerIDs_prepared_df = stage_claims_hdfs_distinct_providerIDs_prepared.get_dataframe()

# -------------------------------------------------------------------------------- NOTEBOOK-CELL: CODE
import random
from faker import Factory
import datetime

faker = Factory.create()

#create static vars
#claim_current_status = '01, 91, 02, , 01, 02, 01, 02'.split(', ')
provider_specialty = '1234, 1199, 2239, 6555, 1310'.split(',')
procedure_code = '9979, C4391, X123, D4578, 9N278, NSZKA, NYH4O, 43IXK, 3P29S, S3I46, 3K2US, 3272D, S3DSHJ, S2GJ3, 32WSS  ,    SN32K, VCGHD, , WSQQS, NULL,   23SDS, XSMJH   , 23KSWA'.split(', ')
#diagnosis_code = 'SJ3YH, SG2IS, SO22S, SI2U3, G654R, LIG5UG, 796IO, 4JKY5, ABVCH, 65P3E, ,DIU3Y   , 43KJJ, 3SDB2   , 231YQ,   21SHJ, HSGZ21, 0, NULL, 2SAGH, S1MHQV, PJO7Y, 654GB, FD3R2, XENW2K,   43EDDS'.split(', ')
#provider_id = '   WEFFER,    FKJ4BH3, FHU34KF   , NULL, F3K4HY   , NFKEWJAB, 23EDEW, 6476YHFG, KJH6K5J7Y    , 3KW45UTH, FKJSEBN, 4354FR, 343453VBDF, GH45K3, JGJKJBAT, KGTNRL, 754HTF, HFU8O34W , FE4U8O, LIU34H, '.split(', ')
provider_entity = 'P, P, P, P, P, P, P, I, G, F'.split(', ')


def fakerecord_providers(df):

    li = []
    for index, row in df.iterrows():
        providers_dict = {
            'provider_id': df['provider_id'][index],
            'provider_specialty': random.choice(provider_specialty),
            'provider_entity': random.choice(provider_entity)
        }
        li.append(providers_dict)
    return li



stage_provider_specialties_li = fakerecord_providers(stage_claims_hdfs_distinct_providerIDs_prepared_df)

# -------------------------------------------------------------------------------- NOTEBOOK-CELL: CODE
providers_df = pd.DataFrame(stage_provider_specialties_li)

# -------------------------------------------------------------------------------- NOTEBOOK-CELL: CODE
# Write recipe outputs
stage_provider_specialties = dataiku.Dataset("stage_provider_specialties")

# -------------------------------------------------------------------------------- NOTEBOOK-CELL: CODE
stage_provider_specialties.write_with_schema(providers_df)

# -------------------------------------------------------------------------------- NOTEBOOK-CELL: CODE
# Recipe outputs
#stage_provider_specialties = dataiku.Dataset("stage_provider_specialties")
#stage_provider_specialties.write_with_schema(stage_provider_specialties)